<?php
    die(header("location: login.php"));
